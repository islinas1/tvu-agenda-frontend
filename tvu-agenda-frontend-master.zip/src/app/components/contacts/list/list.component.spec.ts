import {ComponentFixture, TestBed} from '@angular/core/testing';
import {ContactsComponent} from './list.component';

describe('ContactsComponent', () => {
	let component: ContactsComponent;
	let fixture: ComponentFixture<ContactsComponent>;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			imports: [ContactsComponent]
		}).compileComponents();

		fixture = TestBed.createComponent(ContactsComponent);
		component = fixture.componentInstance;
		await fixture.whenStable();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});
});
