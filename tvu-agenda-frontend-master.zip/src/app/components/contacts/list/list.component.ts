import { Component, OnInit, inject, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatIconModule } from '@angular/material/icon';
import { MatTableModule } from '@angular/material/table';
import { MatChipsModule } from '@angular/material/chips';
import { ContactService } from '../../../services/contact.service';
import { Contact } from '../../../interfaces/contact.interface';
import { Router } from '@angular/router';
import { AuthService } from '../../../services/auth.service';

@Component({
  selector: 'app-contacts',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    MatIconModule,
    MatTableModule,
    MatChipsModule
  ],
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})

export class ContactsComponent implements OnInit {
  constructor(private router: Router, private authService: AuthService) { }

  private contactService = inject(ContactService);
  private cd = inject(ChangeDetectorRef);

  searchQuery: string = '';
  activeFilters: Set<string> = new Set();
  allContacts: Contact[] = [];
  filteredContacts: Contact[] = [];
  displayedColumns: string[] = ['name', 'phones', 'position', 'institution', 'actions'];

  ngOnInit(): void {
    this.loadContacts();
    console.log(this.authService.getUser());
  }

loadContacts(): void {
  this.contactService.getContacts().subscribe({
    next: (data) => {
      this.allContacts = data;
      this.applyFilters();
      this.cd.detectChanges();
    },
    error: (err) => console.error('Error loading contacts', err)
  });
}

applyFilters(): void {
  const text = this.searchQuery.trim().toLowerCase();

  // Si no hay texto de búsqueda ni filtros activos, mostrar todo
  if(text === '' && this.activeFilters.size === 0) {
  this.filteredContacts = [...this.allContacts];
  return;
}

this.filteredContacts = this.allContacts.filter(contact => {

  // filatrado por botones
  if (this.activeFilters.size > 0) {
    return Array.from(this.activeFilters).some(filterType => {
      let value: string | null | undefined;

      if (filterType === 'name') value = contact.contact_name;
      else if (filterType === 'institution') value = contact.contact_institution;
      else if (filterType === 'position') value = contact.contact_position;
      else return false;

      return value?.toString().toLowerCase().includes(text) ?? false;
    });
  }

  // búsqueda global
  const nameMatch = contact.contact_name?.toString().toLowerCase().includes(text) ?? false;
  const institutionMatch = contact.contact_institution?.toString().toLowerCase().includes(text) ?? false;
  const positionMatch = contact.contact_position?.toString().toLowerCase().includes(text) ?? false;
  const phoneMatch = contact.phones?.some(p =>
    p?.phone?.toString().toLowerCase().includes(text)
  ) ?? false;

  return nameMatch || institutionMatch || positionMatch || phoneMatch;
});
  }


newContact(): void {
  this.router.navigate(['/register']);
}

toggleFilter(filter: string): void {
  this.activeFilters.has(filter) ? this.activeFilters.delete(filter) : this.activeFilters.add(filter);
  this.applyFilters();
}

isFilterActive(filter: string): boolean {
  return this.activeFilters.has(filter);
}

clearSearch(): void {
  this.searchQuery = '';
  this.applyFilters();
}

editContact(contact: Contact): void {
  //this.router.navigate(['/edit', contact.id_contact]);
}

deleteContact(contact: Contact): void {
  /*
  if (confirm(`¿Eliminar contacto "${contact.contact_name}"?`)) {
    this.contactService.deleteContact(contact.id_contact).subscribe({
      next: () => {
        this.loadContacts();
      }
    });
  }
    */
}

isAdmin(): boolean {
  return this.authService.isAdmin();
}

}
