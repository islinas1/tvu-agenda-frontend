import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environments';
import { tap } from 'rxjs/operators';
import { LoginResponse } from '../interfaces/login.interface';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private apiUrl = environment.apiUrl + '/auth';

  constructor(private http: HttpClient) { }

  login(ci: string, password?: string): Observable<LoginResponse> {
    return this.http.post<LoginResponse>(`${this.apiUrl}/login`, { ci, password })
      .pipe(
        tap(res => {
          localStorage.setItem('token', res.token);
          localStorage.setItem('user', JSON.stringify(res.user));
        })
      );
  }

  getUser() {
    return JSON.parse(localStorage.getItem('user') || '{}');
  }

  getRole(): number {
    return this.getUser().role_id;
  }

  isAdmin(): boolean {
    return this.getRole() === 1;
  }

  isLoggedIn(): boolean {
    return !!localStorage.getItem('token');
  }

  logout() {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
  }

  checkCI(ci: string): Observable<{ role: 'admin' | 'usuario', redirect: string }> {
    return this.http.post<{ role: 'admin' | 'usuario', redirect: string }>(
      `${this.apiUrl}/check-ci`, { ci }
    );
  }
}